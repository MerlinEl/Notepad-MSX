
Quick Color Picker for Notepad++

------------
 HOW TO USE
------------

This plugin is for Unicode version of Notepad++ only.

Put the NppQCP.dll file into the "plugins" folder of your Notepad++ folder.
Restart Notepad++, and it will enabled automatically.

The color picker works in HTML, CSS and Javascript files.


------------------------
 SOURCE CODE & FEEDBACK
------------------------
Please visit the following website for source and post your feedback.

https://github.com/nulled666/nppqcp/


----------------------------
 LICENSE & ACKNOWLEDGEMENTS
----------------------------
Copyright 2013-2015 NPlus

   Licensed under the Apache License, Version 2.0 (the "License");
   you may not use this file except in compliance with the License.
   You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.

This project is using https://github.com/kkaefer/css-color-parser-cpp/ for css color parse.
